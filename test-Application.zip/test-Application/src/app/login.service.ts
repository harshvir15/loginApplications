import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Observable, throwError } from 'rxjs';
import { catchError, retry } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  status = '';

  constructor(private http: HttpClient) { }

  checkUser(){
    debugger;
    // this.http.post('http://localhost:8080/login', { "id": 1, "username": "Harsh", "password": "test@123"}).subscribe({
    // next: data => this.postId = data.id,
    const headers = { 'Authorization': 'Bearer my-token', 'My-Custom-Header': 'foobar', 'Access-Control-Allow-Origin': 'http://localhost:8080/login'}
    const body = {"id": 1, "username": "Harsh", "password": "test@123"}
    this.http.post<any>('http://localhost:8080/login', body, { headers }).subscribe(data => {
    //console.log("this is my response:---",data);
})

  }
}
