import { Component } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { LoginService } from "./login.service";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {


   constructor(private service: LoginService) { }

  title = 'TestApplication';
  loginForm = new FormGroup({
    userName: new FormControl(''),
    password: new FormControl('')
  });


  onSubmit(){
    debugger;
    console.log(this.loginForm.value);
    this.title = this.loginForm.value.userName;
    this.service.checkUser();
  }

  
}
